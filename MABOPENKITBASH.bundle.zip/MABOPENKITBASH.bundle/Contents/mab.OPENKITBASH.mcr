macroScript OPENKITBASH category:"MYARTSBOX" tooltip:"Open Kitbash"
(
    filein "mab.OPENKITBASH.ms" 
)