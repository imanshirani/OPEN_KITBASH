# ==========================================
# COLOR PALETTE 
# ==========================================
COLOR_ACCENT = "#00aaff"              
COLOR_ACCENT_HOVER = "#0088cc"        
COLOR_ITEM_HOVER = "#3d3d3d"          
COLOR_BG_DARK = "#1a1a1a"             
COLOR_BG_MED = "#2b2b2b"              
COLOR_GROUP_BG = "#252525"            
COLOR_TEXT = "#e0e0e0"                
COLOR_TEXT_LIGHT = "#ffffff"          
COLOR_BORDER = "#3f3f3f"              
COLOR_BORDER_LIGHT = "#555555"        
COLOR_BORDER_DARK = "#444444"         

# button
COLOR_BTN_BG = "#3a3a3a"              
COLOR_BTN_PRESSED = "#222222"         
COLOR_BTN_ACTION_BG = "#005a9e"       
COLOR_BTN_ACTION_BORDER = "#004a87"   
COLOR_BTN_ALT = "#333333"             

# paypal
COLOR_PAYPAL_BG = "#FFC439"
COLOR_PAYPAL_TEXT = "#00457C"
COLOR_PAYPAL_HOVER = "#FFD46A"

# ==========================================
# STYLESHEETS 
# ==========================================

MAIN_STYLE = f"""
QWidget {{
    background-color: {COLOR_BG_MED};
    color: {COLOR_TEXT};
    font-family: 'Segoe UI', sans-serif;
    font-size: 12px;
}}

QListWidget {{
    background-color: {COLOR_BG_DARK};
    border: 1px solid {COLOR_BORDER};
    border-radius: 4px;
    outline: none;
}}
QListWidget::item:hover {{
    background-color: {COLOR_ITEM_HOVER};
}}
QListWidget::item:selected {{
    background-color: {COLOR_ITEM_HOVER};
    border: 1px solid {COLOR_ACCENT}; 
    color: {COLOR_TEXT_LIGHT};
}}

QPushButton {{
    background-color: {COLOR_BTN_BG};
    border: 1px solid {COLOR_BORDER_LIGHT};
    border-radius: 3px;
    color: {COLOR_TEXT};
    padding: 4px;
}}
QPushButton:hover {{
    background-color: {COLOR_ITEM_HOVER};
    border: 1px solid {COLOR_ACCENT}; 
}}
QPushButton:pressed {{
    background-color: {COLOR_BTN_PRESSED};
}}

QLineEdit {{
    background-color: {COLOR_BG_DARK};
    border: 1px solid {COLOR_BORDER_DARK};
    border-radius: 4px;
    padding: 5px;
    color: {COLOR_TEXT}; 
}}
QLineEdit:focus {{
    border: 1px solid {COLOR_ACCENT}; 
}}

QScrollBar:vertical {{
    border: none;
    background: {COLOR_BG_MED};
    width: 8px;
}}
QScrollBar::handle:vertical {{
    background: {COLOR_BORDER_LIGHT};
    min-height: 20px;
    border-radius: 4px;
}}
QScrollBar::handle:vertical:hover {{
    background: {COLOR_ACCENT};
}}
"""

DARK_THEME = MAIN_STYLE

#inster 
BTN_ACTION = f"""
QPushButton {{
    background-color: {COLOR_BTN_ACTION_BG};
    font-weight: bold;
    color: {COLOR_TEXT_LIGHT};
    border: 1px solid {COLOR_BTN_ACTION_BORDER};
}}
QPushButton:hover {{
    background-color: {COLOR_ACCENT};
    color: {COLOR_TEXT_LIGHT};
}}
"""

GROUP_BOX_HEADER = f"""
QGroupBox {{
    font-weight: bold;
    border: 1px solid {COLOR_BORDER};
    border-radius: 5px;
    margin-top: 10px;
    padding-top: 15px;
    background-color: {COLOR_GROUP_BG};
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 10px;
    padding: 0 3px;
    color: {COLOR_ACCENT};
}}
"""

#SpinBox
SPIN_BOX_STYLE = f"""
QDoubleSpinBox {{
    background-color: {COLOR_BG_DARK};
    color: {COLOR_TEXT_LIGHT};
    border: 1px solid {COLOR_BORDER_DARK};
    border-radius: 3px;
    padding: 2px;
    selection-background-color: {COLOR_ACCENT};
}}
QDoubleSpinBox:focus {{
    border: 1px solid {COLOR_ACCENT};
}}
"""

PROGRESS_BAR_STYLE = f"""
    QProgressBar {{
        border: 1px solid {COLOR_BORDER_DARK}; 
        border-radius: 2px; 
        height: 12px; 
        text-align: center; 
        font-size: 9px;
        color: {COLOR_TEXT_LIGHT};
        background-color: {COLOR_BG_DARK};
    }}
    QProgressBar::chunk {{ 
        background-color: {COLOR_ACCENT}; 
        border-radius: 1px;
    }}
"""

ITEM_STYLE = f"""
    QWidget {{
        background-color: {COLOR_BG_MED};
        border-radius: 5px;
        border: 1px solid {COLOR_BORDER};
    }}
    QWidget:hover {{
        background-color: {COLOR_ITEM_HOVER};
        border: 1px solid {COLOR_ACCENT};
    }}
"""

#(PayPal/GitHub/Settings)
BTN_SETTING = f"""
QPushButton {{ 
    background-color: {COLOR_BG_DARK}; 
    color: {COLOR_TEXT_LIGHT}; 
    font-weight: bold; 
    padding: 6px; 
    border-radius: 4px; 
}} 
QPushButton:hover {{ 
    background-color: {COLOR_ITEM_HOVER}; 
    border: 1px solid {COLOR_ACCENT}; 
}}
"""

BTN_GITHUB = f"""
QPushButton {{ 
    background-color: {COLOR_BTN_ALT}; 
    color: {COLOR_TEXT_LIGHT}; 
    font-weight: bold; 
    padding: 6px; 
    border-radius: 4px; 
}} 
QPushButton:hover {{ 
    background-color: {COLOR_ITEM_HOVER}; 
    border: 1px solid {COLOR_ACCENT}; 
}}
"""

BTN_PAYPAL = f"""
QPushButton {{ 
    background-color: {COLOR_PAYPAL_BG}; 
    color: {COLOR_PAYPAL_TEXT}; 
    font-weight: bold; 
    padding: 6px; 
    border-radius: 4px; 
}} 
QPushButton:hover {{ 
    background-color: {COLOR_PAYPAL_HOVER}; 
}}
"""

APP_INFO_LABEL = f"font-size: 11px; color: {COLOR_TEXT};"